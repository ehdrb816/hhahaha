<?php
    session_start();
    session_unset();
    echo ("<script>document.location.href='index.html'</script>");
?>
